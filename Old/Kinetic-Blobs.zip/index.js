/**
 Code inspired by blob example, by David Hirmes
 Flash Math Creativity book - http://friendsofed.com/fmc/downloads/
*/

var canvasWidth = 500, 
    canvasHeight = 400,
    qty = 20,
    radius = 50,
    edgeWidth = 5,
    initialVelocity = 60;

var stage         = new Kinetic.Stage("container", canvasWidth, canvasHeight),
    shapesLayer   = new Kinetic.Layer(),
    ballContainer = new Kinetic.Group();
    edgeContainer = new Kinetic.Group();


var Assets = (function(ballRadius, ballEdge) {

   return {
   
      newBall: function(x,y) { 
         return new Kinetic.Circle({
                         x: x,
                         y: y,
                         fill: "white",
                         stroke: "white",
                         strokeWidth: 0,
                         radius: ballRadius - ballEdge
                     });
      },

      newEdge: function(x,y) { 
         return new Kinetic.Circle({
                         x: x,
                         y: y,
                         fill: "#660000",
                         stroke: "#660000",
                         strokeWidth: 0,
                         radius: ballRadius
                     });
      }
   }
   
})(radius, edgeWidth)

var ballList = [], ball;
for(i=0;i<qty;i++) {
   var x = Math.random() * stage.width;
   var y = (Math.random() * stage.height/2)+(stage.height/4);
   edge = Assets.newEdge(x,y)
   ball =  Assets.newBall(x,y);
   ballList.push({ball: ball, edge: edge, vx: Math.random() * initialVelocity });
   ballContainer.add(ball);
   edgeContainer.add(edge);
}



shapesLayer.add(edgeContainer);
shapesLayer.add(ballContainer);
stage.add(shapesLayer);

stage.onFrame(function(frame){
      var newX;
   	for(i=0;i<qty;i++) {
   		item = ballList[i];
   		newX = item.ball.x + item.vx;
   		if ( newX > stage.width + 40) { newX = -radius; }

   		item.ball.x = newX;
   		item.edge.x = newX;

   		item.vx *= 0.8;
   		if ( item.vx < 0.00001 ) {
   			item.vx = Math.random() * initialVelocity;
   		}

   	}
      stage.draw();
});

stage.start();
